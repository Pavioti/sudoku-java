package com.mycompany.sudoku;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class JogoSudoku extends JFrame {

    private int tamanho = 4;
    private int blocoLinhas = 2;
    private int blocoColunas = 2;

    private JButton[][] botoes;
    private JButton[] botoesNumeros;
    private final Random random = new Random();

    private int[][] solucao;
    private int[][] inicial;
    private JButton botaoSelecionado;

    private JPanel painelMenu;
    private JPanel painelJogo;
    private JPanel painelRaiz;
    private JLabel etiquetaProgresso;
    private JLabel etiquetaStatus;

    private boolean modoEscuro = false;
    private boolean avisarErroImediatamente = true;
    private int dicasRestantes = 3;
    private boolean partidaFinalizada = false;

    private Color fundo;
    private Color texto;
    private Color celulaFixa;
    private Color celulaVazia;
    private Color celulaSelecionada;
    private Color celulaDestaque;
    private Color textoJogador;
    private Color fundoBotoes;
    private Color textoErro;

    public JogoSudoku() {
        setTitle("Sudoku 4x4");
        setSize(900, 950);
        setMinimumSize(new Dimension(700, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        painelRaiz = new JPanel(new CardLayout());
        setContentPane(painelRaiz);

        atualizarCores();
        criarMenuPrincipal();
        setVisible(true);
    }

    private void definirTamanho(int novoTamanho) {
        tamanho = novoTamanho;
        blocoLinhas = 2;
        blocoColunas = tamanho / 2;
        botoes = new JButton[tamanho][tamanho];
    }

    private void atualizarCores() {
        if (modoEscuro) {
            fundo = new Color(35, 35, 40);
            texto = new Color(240, 240, 240);
            celulaFixa = new Color(75, 75, 82);
            celulaVazia = new Color(50, 50, 57);
            celulaSelecionada = new Color(105, 90, 45);
            celulaDestaque = new Color(70, 70, 80);
            textoJogador = new Color(100, 180, 255);
            fundoBotoes = new Color(65, 65, 72);
            textoErro = new Color(255, 110, 110);
        } else {
            fundo = new Color(245, 245, 245);
            texto = new Color(30, 30, 30);
            celulaFixa = new Color(215, 215, 215);
            celulaVazia = Color.WHITE;
            celulaSelecionada = new Color(255, 255, 153);
            celulaDestaque = new Color(235, 240, 250);
            textoJogador = new Color(0, 102, 204);
            fundoBotoes = new Color(235, 235, 235);
            textoErro = new Color(190, 30, 30);
        }
    }

    private void criarMenuPrincipal() {
        painelMenu = new JPanel(new BorderLayout(20, 20));
        painelMenu.setBorder(BorderFactory.createEmptyBorder(35, 55, 35, 55));

        JPanel cabecalho = new JPanel(new BorderLayout(8, 8));
        cabecalho.setOpaque(false);
        JLabel titulo = new JLabel("Sudoku", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 46));
        JLabel subtitulo = new JLabel("Um jogo de raciocínio simples e tranquilo", SwingConstants.CENTER);
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 21));
        cabecalho.add(titulo, BorderLayout.NORTH);
        cabecalho.add(subtitulo, BorderLayout.CENTER);
        painelMenu.add(cabecalho, BorderLayout.NORTH);

        JPanel painelCentral = new JPanel();
        painelCentral.setLayout(new BoxLayout(painelCentral, BoxLayout.Y_AXIS));
        painelCentral.setOpaque(false);

        JPanel cardTamanho = criarCard();
        JLabel tituloTamanho = new JLabel("Tamanho do tabuleiro", SwingConstants.CENTER);
        tituloTamanho.setAlignmentX(Component.CENTER_ALIGNMENT);
        tituloTamanho.setFont(new Font("Arial", Font.BOLD, 25));

        JLabel ajudaTamanho = new JLabel("Escolha um tamanho para começar", SwingConstants.CENTER);
        ajudaTamanho.setAlignmentX(Component.CENTER_ALIGNMENT);
        ajudaTamanho.setFont(new Font("Arial", Font.PLAIN, 18));

        JPanel botoesTamanho = new JPanel(new GridLayout(1, 4, 10, 0));
        botoesTamanho.setOpaque(false);
        ButtonGroup grupoTamanho = new ButtonGroup();
        JToggleButton[] opcoesTamanho = new JToggleButton[4];
        int[] tamanhos = {4, 6, 8, 10};
        for (int i = 0; i < tamanhos.length; i++) {
            final int indice = i;
            JToggleButton opcao = new JToggleButton(tamanhos[i] + "x" + tamanhos[i]);
            opcao.setFont(new Font("Arial", Font.BOLD, 22));
            opcao.setFocusPainted(false);
            opcao.setPreferredSize(new Dimension(120, 58));
            opcao.setSelected(i == 0);
            opcao.addActionListener(e -> {
                definirTamanho(tamanhos[indice]);
                setTitle("Sudoku " + tamanho + "x" + tamanho);
                atualizarSelecaoTamanhos(opcoesTamanho);
            });
            grupoTamanho.add(opcao);
            botoesTamanho.add(opcao);
            opcoesTamanho[i] = opcao;
        }
        definirTamanho(4);
        cardTamanho.add(tituloTamanho);
        cardTamanho.add(Box.createVerticalStrut(5));
        cardTamanho.add(ajudaTamanho);
        cardTamanho.add(Box.createVerticalStrut(15));
        cardTamanho.add(botoesTamanho);

        JPanel cardOpcoes = criarCard();
        JLabel tituloOpcoes = new JLabel("Opções", SwingConstants.CENTER);
        tituloOpcoes.setAlignmentX(Component.CENTER_ALIGNMENT);
        tituloOpcoes.setFont(new Font("Arial", Font.BOLD, 25));

        JButton tema = criarBotao("Modo Escuro", 23);
        atualizarTextoTema(tema);
        tema.setAlignmentX(Component.CENTER_ALIGNMENT);
        tema.addActionListener(e -> {
            modoEscuro = !modoEscuro;
            atualizarCores();
            aplicarTema();
            atualizarTextoTema(tema);
        });

        JCheckBox avisoErro = new JCheckBox("Mostrar número errado em vermelho");
        avisoErro.setFont(new Font("Arial", Font.BOLD, 19));
        avisoErro.setSelected(avisarErroImediatamente);
        avisoErro.setOpaque(false);
        avisoErro.setAlignmentX(Component.CENTER_ALIGNMENT);
        avisoErro.addActionListener(e -> avisarErroImediatamente = avisoErro.isSelected());

        cardOpcoes.add(tituloOpcoes);
        cardOpcoes.add(Box.createVerticalStrut(12));
        cardOpcoes.add(tema);
        cardOpcoes.add(Box.createVerticalStrut(8));
        cardOpcoes.add(avisoErro);

        JPanel botoesAcao = new JPanel(new GridLayout(1, 2, 15, 0));
        botoesAcao.setOpaque(false);
        JButton instrucoes = criarBotao("Como Jogar", 24);
        instrucoes.addActionListener(e -> mostrarInstrucoes());
        JButton sair = criarBotao("Sair do Jogo", 24);
        sair.addActionListener(e -> System.exit(0));
        botoesAcao.add(instrucoes);
        botoesAcao.add(sair);

        JButton jogar = criarBotao("JOGAR", 30);
        jogar.setAlignmentX(Component.CENTER_ALIGNMENT);
        jogar.setPreferredSize(new Dimension(360, 72));
        jogar.addActionListener(e -> iniciarJogo("Fácil"));

        painelCentral.add(cardTamanho);
        painelCentral.add(Box.createVerticalStrut(15));
        painelCentral.add(cardOpcoes);
        painelCentral.add(Box.createVerticalStrut(18));
        painelCentral.add(jogar);
        painelCentral.add(Box.createVerticalStrut(15));
        painelCentral.add(botoesAcao);
        painelMenu.add(painelCentral, BorderLayout.CENTER);

        JLabel acessibilidade = new JLabel("Números grandes • botões grandes • interface fácil de ler", SwingConstants.CENTER);
        acessibilidade.setFont(new Font("Arial", Font.PLAIN, 19));
        painelMenu.add(acessibilidade, BorderLayout.SOUTH);
        painelRaiz.add(painelMenu, "Menu");

        aplicarTema();
        atualizarSelecaoTamanhos(opcoesTamanho);
    }

    private void atualizarSelecaoTamanhos(JToggleButton[] opcoes) {
        for (JToggleButton botao : opcoes) {
            botao.setBackground(botao.isSelected() ? celulaSelecionada : fundoBotoes);
            botao.setForeground(texto);
        }
    }

    private JPanel criarCard() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(true);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(190, 190, 190), 1),
                BorderFactory.createEmptyBorder(18, 22, 18, 22)
        ));
        return card;
    }

    private JButton criarBotao(String textoBotao, int tamanhoFonte) {
        JButton botao = new JButton(textoBotao);
        botao.setFont(new Font("Arial", Font.BOLD, tamanhoFonte));
        botao.setFocusPainted(false);
        botao.setOpaque(true);
        botao.setPreferredSize(new Dimension(220, 64));
        botao.setMargin(new Insets(10, 18, 10, 18));
        return botao;
    }

    private void atualizarTextoTema(JButton botao) {
        botao.setText(modoEscuro ? "Modo Claro" : "Modo Escuro");
    }

    private void mostrarInstrucoes() {
        String texto =
                "Como jogar o Sudoku " + tamanho + "x" + tamanho + ":\n\n" +
                "1. Escolha um quadrado vazio.\n" +
                "2. Escolha um número nos botões abaixo.\n" +
                "3. Não repita números na mesma linha, coluna ou bloco.\n" +
                "4. Os números cinzas são fixos.\n" +
                "5. Use APAGAR para corrigir uma casa.\n" +
                "6. Use DICA se precisar de ajuda.\n" +
                "7. Use VERIFICAR para conferir o progresso.\n\n" +
                "Cada nova partida gera uma solução aleatória e única.";

        JOptionPane.showMessageDialog(this, texto, "Instruções", JOptionPane.INFORMATION_MESSAGE);
    }

    private int[][] gerarSolucaoAleatoria() {
        int[][] tabuleiro = new int[tamanho][tamanho];
        preencherAleatorio(tabuleiro, 0, 0);
        return tabuleiro;
    }

    private boolean preencherAleatorio(int[][] tabuleiro, int linha, int coluna) {
        if (linha == tamanho) return true;

        int proximaLinha = coluna == tamanho - 1 ? linha + 1 : linha;
        int proximaColuna = coluna == tamanho - 1 ? 0 : coluna + 1;

        List<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= tamanho; i++) numeros.add(i);
        Collections.shuffle(numeros, random);

        for (int numero : numeros) {
            if (podeColocar(tabuleiro, linha, coluna, numero)) {
                tabuleiro[linha][coluna] = numero;
                if (preencherAleatorio(tabuleiro, proximaLinha, proximaColuna)) return true;
                tabuleiro[linha][coluna] = 0;
            }
        }
        return false;
    }

    private boolean podeColocar(int[][] tabuleiro, int linha, int coluna, int numero) {
        for (int i = 0; i < tamanho; i++) {
            if (tabuleiro[linha][i] == numero || tabuleiro[i][coluna] == numero) return false;
        }

        int baseLinha = (linha / blocoLinhas) * blocoLinhas;
        int baseColuna = (coluna / blocoColunas) * blocoColunas;

        for (int l = baseLinha; l < baseLinha + blocoLinhas; l++) {
            for (int c = baseColuna; c < baseColuna + blocoColunas; c++) {
                if (tabuleiro[l][c] == numero) return false;
            }
        }
        return true;
    }

    private int[][] criarTabuleiroInicial(int[][] solucao, int quantidadeDeVazios) {
        int[][] tabuleiro = copiarMatriz(solucao);
        List<Integer> posicoes = new ArrayList<>();
        for (int i = 0; i < tamanho * tamanho; i++) posicoes.add(i);
        Collections.shuffle(posicoes, random);

        int vaziosDesejados = Math.min(quantidadeDeVazios, tamanho * tamanho - tamanho);
        int removidos = 0;

        for (int posicao : posicoes) {
            if (removidos >= vaziosDesejados) break;
            int linha = posicao / tamanho;
            int coluna = posicao % tamanho;
            int salvo = tabuleiro[linha][coluna];
            tabuleiro[linha][coluna] = 0;

            if (contarSolucoes(tabuleiro, 2) == 1) {
                removidos++;
            } else {
                tabuleiro[linha][coluna] = salvo;
            }
        }

        return tabuleiro;
    }

    private int contarSolucoes(int[][] tabuleiro, int limite) {
        return contarSolucoesRecursivo(tabuleiro, limite, 0);
    }

    private int contarSolucoesRecursivo(int[][] tabuleiro, int limite, int encontradas) {
        if (encontradas >= limite) return encontradas;

        int melhorLinha = -1;
        int melhorColuna = -1;
        List<Integer> melhoresCandidatos = null;

        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                if (tabuleiro[l][c] != 0) continue;
                List<Integer> candidatos = candidatosValidos(tabuleiro, l, c);
                if (candidatos.isEmpty()) return encontradas;
                if (melhoresCandidatos == null || candidatos.size() < melhoresCandidatos.size()) {
                    melhorLinha = l;
                    melhorColuna = c;
                    melhoresCandidatos = candidatos;
                    if (candidatos.size() == 1) break;
                }
            }
            if (melhoresCandidatos != null && melhoresCandidatos.size() == 1) break;
        }

        if (melhoresCandidatos == null) return encontradas + 1;

        for (int numero : melhoresCandidatos) {
            tabuleiro[melhorLinha][melhorColuna] = numero;
            encontradas = contarSolucoesRecursivo(tabuleiro, limite, encontradas);
            tabuleiro[melhorLinha][melhorColuna] = 0;
            if (encontradas >= limite) break;
        }
        return encontradas;
    }

    private List<Integer> candidatosValidos(int[][] tabuleiro, int linha, int coluna) {
        List<Integer> candidatos = new ArrayList<>();
        for (int numero = 1; numero <= tamanho; numero++) {
            if (podeColocar(tabuleiro, linha, coluna, numero)) candidatos.add(numero);
        }
        return candidatos;
    }

    private int[][] copiarMatriz(int[][] original) {
        int[][] copia = new int[tamanho][tamanho];
        for (int l = 0; l < tamanho; l++) System.arraycopy(original[l], 0, copia[l], 0, tamanho);
        return copia;
    }

    private int quantidadeDeVazios() {
        return switch (tamanho) {
            case 4 -> 6;
            case 6 -> 14;
            case 8 -> 30;
            case 10 -> 55;
            default -> tamanho * tamanho / 2;
        };
    }

    private void iniciarJogo(String dificuldade) {
        solucao = gerarSolucaoAleatoria();
        inicial = criarTabuleiroInicial(solucao, quantidadeDeVazios());
        botaoSelecionado = null;
        dicasRestantes = 3;
        partidaFinalizada = false;

        painelJogo = new JPanel(new BorderLayout(15, 15));
        painelJogo.setBorder(BorderFactory.createEmptyBorder(15, 15, 20, 15));

        JPanel topo = new JPanel(new BorderLayout(12, 12));

        JButton voltar = criarBotao("Voltar", 22);
        voltar.addActionListener(e -> confirmarVoltar());

        JLabel titulo = new JLabel("Sudoku " + tamanho + "x" + tamanho + " - " + dificuldade, SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));

        JButton novo = criarBotao("Novo", 22);
        novo.addActionListener(e -> confirmarNovoJogo(dificuldade));

        topo.add(voltar, BorderLayout.WEST);
        topo.add(titulo, BorderLayout.CENTER);
        topo.add(novo, BorderLayout.EAST);
        painelJogo.add(topo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setOpaque(false);

        etiquetaProgresso = new JLabel("Progresso: 0 / " + contarCasasVaziasIniciais(), SwingConstants.CENTER);
        etiquetaProgresso.setFont(new Font("Arial", Font.BOLD, 20));
        centro.add(etiquetaProgresso, BorderLayout.NORTH);

        JPanel tabuleiro = new JPanel(new GridLayout(tamanho, tamanho, tamanho <= 6 ? 7 : 4, tamanho <= 6 ? 7 : 4));
        tabuleiro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        tabuleiro.setOpaque(false);

        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) criarCelula(tabuleiro, linha, coluna);
        }
        centro.add(tabuleiro, BorderLayout.CENTER);

        etiquetaStatus = new JLabel("Selecione uma casa para começar.", SwingConstants.CENTER);
        etiquetaStatus.setFont(new Font("Arial", Font.BOLD, 18));
        centro.add(etiquetaStatus, BorderLayout.SOUTH);
        painelJogo.add(centro, BorderLayout.CENTER);

        JPanel inferior = new JPanel(new BorderLayout(10, 10));
        inferior.setOpaque(false);
        inferior.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

        int colunasTeclado = tamanho <= 5 ? tamanho + 1 : 5;
        int linhasTeclado = (int) Math.ceil((tamanho + 1) / (double) colunasTeclado);
        JPanel teclado = new JPanel(new GridLayout(linhasTeclado, colunasTeclado, 8, 8));
        teclado.setOpaque(false);

        botoesNumeros = new JButton[tamanho];
        int fonteNumero = tamanho <= 6 ? 32 : 25;
        for (int numero = 1; numero <= tamanho; numero++) {
            final String valor = String.valueOf(numero);
            JButton botaoNumero = criarBotao(valor, fonteNumero);
            botaoNumero.addActionListener(e -> colocarNumero(valor));
            botoesNumeros[numero - 1] = botaoNumero;
            teclado.add(botaoNumero);
        }

        JButton apagar = criarBotao("APAGAR", tamanho <= 6 ? 25 : 20);
        apagar.addActionListener(e -> apagarSelecionado());
        teclado.add(apagar);
        inferior.add(teclado, BorderLayout.CENTER);

        JPanel comandos = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        comandos.setOpaque(false);
        JButton dica = criarBotao("DICA (3)", 22);
        dica.addActionListener(e -> usarDica(dica));
        JButton verificar = criarBotao("VERIFICAR", 22);
        verificar.addActionListener(e -> executarBotaoChecar());
        comandos.add(dica);
        comandos.add(verificar);
        inferior.add(comandos, BorderLayout.SOUTH);

        painelJogo.add(inferior, BorderLayout.SOUTH);
        painelRaiz.add(painelJogo, "Jogo");
        aplicarTema();
        ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Jogo");
        setTitle("Sudoku " + tamanho + "x" + tamanho + " - " + dificuldade);
        atualizarProgresso();
        revalidate();
        repaint();
    }

    private int contarCasasVaziasIniciais() {
        int total = 0;
        for (int l = 0; l < tamanho; l++) for (int c = 0; c < tamanho; c++) if (inicial[l][c] == 0) total++;
        return total;
    }

    private void confirmarVoltar() {
        if (partidaFinalizada || confirmar("Deseja realmente voltar ao menu?\nO progresso desta partida será perdido.")) {
            botaoSelecionado = null;
            ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Menu");
            setTitle("Sudoku " + tamanho + "x" + tamanho);
        }
    }

    private void confirmarNovoJogo(String dificuldade) {
        if (confirmar("Começar um novo jogo?\nO progresso atual será perdido.")) iniciarJogo(dificuldade);
    }

    private boolean confirmar(String mensagem) {
        int resposta = JOptionPane.showConfirmDialog(this, mensagem, "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return resposta == JOptionPane.YES_OPTION;
    }

    private void colocarNumero(String valor) {
        if (partidaFinalizada || botaoSelecionado == null) return;

        botaoSelecionado.setText(valor);
        int[] posicao = encontrarPosicao(botaoSelecionado);
        if (posicao[0] == -1) return;

        int linha = posicao[0], coluna = posicao[1];
        boolean errado = solucao[linha][coluna] != Integer.parseInt(valor);
        botaoSelecionado.setForeground(avisarErroImediatamente && errado ? textoErro : textoJogador);
        etiquetaStatus.setText(errado ? "Número incorreto. Você pode corrigir sem interromper a partida." : "Número colocado corretamente.");
        atualizarSelecao();
        atualizarProgresso();
        atualizarBotoesNumeros();
        verificarVitoriaSilenciosa();
    }

    private void apagarSelecionado() {
        if (partidaFinalizada || botaoSelecionado == null) return;
        botaoSelecionado.setText("");
        botaoSelecionado.setForeground(textoJogador);
        etiquetaStatus.setText("Casa apagada.");
        atualizarProgresso();
        atualizarBotoesNumeros();
    }

    private void usarDica(JButton botaoDica) {
        if (partidaFinalizada || dicasRestantes <= 0) return;

        List<Point> vazias = new ArrayList<>();
        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                if (inicial[l][c] == 0 && valorDaCelula(l, c) != solucao[l][c]) vazias.add(new Point(c, l));
            }
        }

        if (vazias.isEmpty()) {
            etiquetaStatus.setText("Não há nenhuma casa que precise de dica.");
            return;
        }

        Point ponto = vazias.get(random.nextInt(vazias.size()));
        JButton casa = botoes[ponto.y][ponto.x];
        selecionarCelula(casa);
        casa.setText(String.valueOf(solucao[ponto.y][ponto.x]));
        casa.setForeground(textoJogador);
        dicasRestantes--;
        botaoDica.setText("DICA (" + dicasRestantes + ")");
        etiquetaStatus.setText("Dica usada. Restam " + dicasRestantes + ".");
        atualizarProgresso();
        atualizarBotoesNumeros();
        verificarVitoriaSilenciosa();
    }

    private void selecionarCelula(JButton botao) {
        if (botaoSelecionado != null) atualizarSelecao();
        botaoSelecionado = botao;
        atualizarSelecao();
    }

    private void atualizarSelecao() {
        if (botoes == null) return;
        int linhaSelecionada = -1;
        int colunaSelecionada = -1;
        if (botaoSelecionado != null) {
            int[] p = encontrarPosicao(botaoSelecionado);
            linhaSelecionada = p[0];
            colunaSelecionada = p[1];
        }

        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                JButton botao = botoes[l][c];
                if (botao == null) continue;
                aplicarCorCelula(botao, l, c, l == linhaSelecionada || c == colunaSelecionada);
            }
        }
    }

    private void aplicarCorCelula(JButton botao, int linha, int coluna, boolean destaque) {
        if (inicial[linha][coluna] != 0) {
            botao.setBackground(celulaFixa);
            botao.setBorder(UIManager.getBorder("Button.border"));
            botao.setForeground(texto);
            return;
        }

        if (botao == botaoSelecionado) {
            botao.setBackground(celulaSelecionada);
            botao.setBorder(new LineBorder(textoJogador, 3));
        } else if (destaque) {
            botao.setBackground(celulaDestaque);
            botao.setBorder(new LineBorder(textoJogador, 1));
        } else {
            botao.setBackground(celulaVazia);
            botao.setBorder(UIManager.getBorder("Button.border"));
        }

        if (!botao.getText().isEmpty() && avisarErroImediatamente) {
            int[] p = encontrarPosicao(botao);
            if (p[0] >= 0 && valorDaCelula(p[0], p[1]) != solucao[p[0]][p[1]]) botao.setForeground(textoErro);
            else botao.setForeground(textoJogador);
        } else {
            botao.setForeground(textoJogador);
        }
    }

    private int[] encontrarPosicao(JButton botao) {
        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                if (botoes[l][c] == botao) return new int[]{l, c};
            }
        }
        return new int[]{-1, -1};
    }

    private void criarCelula(JPanel tabuleiro, int linha, int coluna) {
        int numeroInicial = inicial[linha][coluna];
        JButton botao = new JButton();
        int fonte = tamanho <= 6 ? 44 : (tamanho <= 8 ? 30 : 23);
        botao.setFont(new Font("Arial", Font.BOLD, fonte));
        botao.setFocusPainted(false);
        botao.setOpaque(true);

        if (numeroInicial != 0) {
            botao.setText(String.valueOf(numeroInicial));
            botao.setForeground(texto);
            botao.setBackground(celulaFixa);
            botao.setEnabled(false);
        } else {
            botao.setBackground(celulaVazia);
            botao.setForeground(textoJogador);
            botao.addActionListener(e -> {
                selecionarCelula(botao);
                etiquetaStatus.setText("Casa selecionada. Escolha um número.");
            });
        }
        botoes[linha][coluna] = botao;
        tabuleiro.add(botao);
    }

    private int valorDaCelula(int linha, int coluna) {
        String textoBotao = botoes[linha][coluna].getText();
        return textoBotao.isEmpty() ? 0 : Integer.parseInt(textoBotao);
    }

    private boolean temConflito(int linha, int coluna) {
        int valor = valorDaCelula(linha, coluna);
        if (valor == 0) return false;

        for (int i = 0; i < tamanho; i++) {
            if (i != coluna && valorDaCelula(linha, i) == valor) return true;
            if (i != linha && valorDaCelula(i, coluna) == valor) return true;
        }

        int baseLinha = (linha / blocoLinhas) * blocoLinhas;
        int baseColuna = (coluna / blocoColunas) * blocoColunas;
        for (int l = baseLinha; l < baseLinha + blocoLinhas; l++) {
            for (int c = baseColuna; c < baseColuna + blocoColunas; c++) {
                if ((l != linha || c != coluna) && valorDaCelula(l, c) == valor) return true;
            }
        }
        return false;
    }

    private boolean tabuleiroCompletoECorreto() {
        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                if (valorDaCelula(l, c) == 0) return false;
                if (valorDaCelula(l, c) != solucao[l][c]) return false;
            }
        }
        return true;
    }

    private void verificarVitoriaSilenciosa() {
        if (tabuleiroCompletoECorreto() && !partidaFinalizada) {
            partidaFinalizada = true;
            mostrarTelaVitoria();
        }
    }

    private void mostrarTelaVitoria() {
        JPanel vitoria = new JPanel(new BorderLayout(20, 20));
        vitoria.setBorder(BorderFactory.createEmptyBorder(70, 50, 70, 50));

        JLabel titulo = new JLabel("PARABÉNS!", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 48));

        JLabel mensagem = new JLabel("Você completou o Sudoku " + tamanho + "x" + tamanho + "!", SwingConstants.CENTER);
        mensagem.setFont(new Font("Arial", Font.PLAIN, 25));

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton novo = criarBotao("NOVO JOGO", 24);
        novo.addActionListener(e -> iniciarJogo("Fácil"));
        JButton menu = criarBotao("VOLTAR AO MENU", 24);
        menu.addActionListener(e -> {
            ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Menu");
            setTitle("Sudoku " + tamanho + "x" + tamanho);
        });
        botoes.add(novo);
        botoes.add(menu);

        vitoria.add(titulo, BorderLayout.NORTH);
        vitoria.add(mensagem, BorderLayout.CENTER);
        vitoria.add(botoes, BorderLayout.SOUTH);
        painelRaiz.add(vitoria, "Vitoria");
        aplicarTemaPainel(vitoria);
        ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Vitoria");
        setTitle("Sudoku - Parabéns!");
    }

    private void executarBotaoChecar() {
        if (partidaFinalizada) return;
        int erros = 0, vazios = 0;
        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                int valor = valorDaCelula(l, c);
                if (valor == 0) vazios++;
                else if (valor != solucao[l][c]) {
                    erros++;
                    if (inicial[l][c] == 0 && avisarErroImediatamente) botoes[l][c].setForeground(textoErro);
                }
            }
        }

        if (erros > 0) {
            etiquetaStatus.setText("Há " + erros + " número(s) para corrigir. Continue com calma.");
        } else if (vazios > 0) {
            etiquetaStatus.setText("Tudo certo até agora! Faltam " + vazios + " casa(s).");
        } else {
            verificarVitoriaSilenciosa();
        }
        atualizarProgresso();
        atualizarSelecao();
    }

    private void atualizarProgresso() {
        if (etiquetaProgresso == null || botoes == null) return;
        int total = contarCasasVaziasIniciais();
        int preenchidas = 0;
        for (int l = 0; l < tamanho; l++) {
            for (int c = 0; c < tamanho; c++) {
                if (inicial[l][c] == 0 && valorDaCelula(l, c) != 0) preenchidas++;
            }
        }
        etiquetaProgresso.setText("Progresso: " + preenchidas + " / " + total);
    }

    private void atualizarBotoesNumeros() {
        if (botoesNumeros == null) return;
        for (int i = 0; i < botoesNumeros.length; i++) {
            int numero = i + 1;
            int restante = 0;
            for (int l = 0; l < tamanho; l++) {
                for (int c = 0; c < tamanho; c++) {
                    if (inicial[l][c] == 0 && valorDaCelula(l, c) == numero) restante++;
                }
            }
            botoesNumeros[i].setToolTipText("Número " + numero + " usado " + restante + " vez(es)");
        }
    }

    private void aplicarTema() {
        atualizarCores();
        getContentPane().setBackground(fundo);
        if (painelMenu != null) {
            painelMenu.setBackground(fundo);
            atualizarComponentes(painelMenu);
        }
        if (painelJogo != null) {
            painelJogo.setBackground(fundo);
            atualizarComponentes(painelJogo);
            if (botoes != null && inicial != null) {
                for (int l = 0; l < tamanho; l++) {
                    for (int c = 0; c < tamanho; c++) {
                        JButton botao = botoes[l][c];
                        if (botao == null) continue;
                        aplicarCorCelula(botao, l, c, false);
                    }
                }
                atualizarSelecao();
            }
        }
        SwingUtilities.updateComponentTreeUI(this);
        repaint();
    }

    private void aplicarTemaPainel(JPanel painel) {
        painel.setBackground(fundo);
        atualizarComponentes(painel);
        SwingUtilities.updateComponentTreeUI(this);
    }

    private void atualizarComponentes(Container container) {
        for (Component componente : container.getComponents()) {
            if (componente instanceof JLabel) componente.setForeground(texto);
            if (componente instanceof JButton) {
                componente.setForeground(texto);
                componente.setBackground(fundoBotoes);
            }
            if (componente instanceof JCheckBox) {
                componente.setForeground(texto);
                componente.setBackground(fundo);
            }
            if (componente instanceof JComboBox<?>) {
                componente.setForeground(texto);
                componente.setBackground(fundoBotoes);
            }
            if (componente instanceof JPanel painel) {
                if (painel.isOpaque()) painel.setBackground(fundo);
                atualizarComponentes(painel);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(JogoSudoku::new);
    }
}

package jogoguiazado;

import javax.swing.*;
import java.awt.*;

public class JogoSudoku extends JFrame {

    // Soluções de referência (a verificação agora é feita pelas regras do Sudoku,
    // então qualquer solução válida é aceita, não só esta).
    private final int[][] SOLUCAO_FACIL = {
        {1, 2, 3, 4},
        {3, 4, 1, 2},
        {2, 3, 4, 1},
        {4, 1, 2, 3}
    };

    private final int[][] INICIAL_FACIL = {
        {1, 0, 3, 0},
        {0, 4, 0, 2},
        {2, 0, 4, 0},
        {0, 1, 0, 3}
    };

    private final int[][] SOLUCAO_MEDIO = {
        {2, 1, 4, 3},
        {4, 3, 2, 1},
        {1, 2, 3, 4},
        {3, 4, 1, 2}
    };

    private final int[][] INICIAL_MEDIO = {
        {0, 0, 4, 0},
        {4, 0, 0, 0},
        {0, 0, 0, 4},
        {0, 4, 0, 0}
    };

    private int[][] solucaoAtual;
    private int[][] inicialAtual;

    private JButton[][] botoes = new JButton[4][4];
    private JButton botaoSelecionado = null;
    private JPanel painelMenu;
    private JPanel painelJogo;

    public JogoSudoku() {
        setTitle("Sudoku Super Fácil");
        setSize(500, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new CardLayout());

        criarMenuPrincipal();

        setVisible(true);
    }

    private void criarMenuPrincipal() {
        painelMenu = new JPanel(new BorderLayout(20, 20));
        painelMenu.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        painelMenu.setBackground(new Color(245, 245, 245));

        JLabel lblBoasVindas = new JLabel("Jogo do Sudoku", SwingConstants.CENTER);
        lblBoasVindas.setFont(new Font("Arial", Font.BOLD, 32));
        painelMenu.add(lblBoasVindas, BorderLayout.NORTH);

        JPanel painelBotoesMenu = new JPanel(new GridLayout(4, 1, 0, 15));
        painelBotoesMenu.setOpaque(false);

        JButton btnComoJogar = criarBotaoMenu("📖 Como Jogar (Instruções)", 20, new Color(255, 255, 204));
        btnComoJogar.addActionListener(e -> mostrarInstrucoes());

        JButton btnFacil = criarBotaoMenu("🟢 Jogar Modo Fácil", 22, new Color(204, 255, 204));
        btnFacil.addActionListener(e -> iniciarJogo(INICIAL_FACIL, SOLUCAO_FACIL, "Modo: Fácil"));

        JButton btnMedio = criarBotaoMenu("🟡 Jogar Modo Médio", 22, new Color(255, 229, 204));
        btnMedio.addActionListener(e -> iniciarJogo(INICIAL_MEDIO, SOLUCAO_MEDIO, "Modo: Médio"));

        JButton btnSair = criarBotaoMenu("❌ Sair do Jogo", 18, new Color(255, 204, 204));
        btnSair.addActionListener(e -> System.exit(0));

        painelBotoesMenu.add(btnComoJogar);
        painelBotoesMenu.add(btnFacil);
        painelBotoesMenu.add(btnMedio);
        painelBotoesMenu.add(btnSair);

        painelMenu.add(painelBotoesMenu, BorderLayout.CENTER);
        add(painelMenu, "Menu");
    }

    private JButton criarBotaoMenu(String texto, int tamanhoFonte, Color cor) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Arial", Font.BOLD, tamanhoFonte));
        b.setBackground(cor);
        b.setOpaque(true);
        b.setFocusPainted(false);
        return b;
    }

    private void mostrarInstrucoes() {
        String texto = "Como Jogar o Sudoku 4x4:\n\n"
                     + "1. O tabuleiro possui quadrados brancos e cinzas.\n"
                     + "2. Os cinzas são fixos e não mudam.\n"
                     + "3. Clique em qualquer quadrado BRANCO. Ele ficará amarelo.\n"
                     + "4. Com o quadrado amarelo, clique em um número (1, 2, 3 ou 4) lá embaixo.\n"
                     + "5. O objetivo é preencher sem repetir números na mesma linha, coluna\n"
                     + "    ou bloco 2x2.\n"
                     + "6. Clique em 'VERIFICAR' a qualquer momento para ver se acertou!";

        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.PLAIN, 18));
        UIManager.put("OptionPane.buttonFont", new Font("Arial", Font.BOLD, 16));
        JOptionPane.showMessageDialog(this, texto, "Instruções do Jogo", JOptionPane.INFORMATION_MESSAGE);
    }

    private void iniciarJogo(int[][] inicial, int[][] solucao, String modoTexto) {
        this.inicialAtual = inicial;
        this.solucaoAtual = solucao;
        this.botaoSelecionado = null;

        if (painelJogo != null) {
            remove(painelJogo);
        }

        painelJogo = new JPanel(new BorderLayout(15, 15));
        painelJogo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel painelTopo = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("1º Escolha o quadrado branco -> 2º Escolha o número embaixo", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 13));
        setTitle("Sudoku - " + modoTexto);

        JButton btnVoltar = new JButton("⬅ Voltar ao Menu");
        btnVoltar.setFont(new Font("Arial", Font.BOLD, 12));
        btnVoltar.addActionListener(e -> {
            setTitle("Sudoku Super Fácil");
            CardLayout cl = (CardLayout) getContentPane().getLayout();
            cl.show(getContentPane(), "Menu");
        });

        painelTopo.add(btnVoltar, BorderLayout.WEST);
        painelTopo.add(lblTitulo, BorderLayout.CENTER);
        painelJogo.add(painelTopo, BorderLayout.NORTH);

        JPanel painelTabuleiro = new JPanel(new GridLayout(4, 4, 10, 10));
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));

        for (int linha = 0; linha < 4; linha++) {
            for (int coluna = 0; coluna < 4; coluna++) {
                int numeroInicial = inicialAtual[linha][coluna];
                JButton botao = new JButton();
                botao.setFont(new Font("Arial", Font.BOLD, 36));
                botao.setFocusPainted(false);
                botao.setOpaque(true);

                if (numeroInicial != 0) {
                    // Casa fixa: sem listener (não é desabilitada para o texto continuar preto)
                    botao.setText(String.valueOf(numeroInicial));
                    botao.setBackground(new Color(210, 210, 210));
                    botao.setForeground(Color.BLACK);
                    botao.setRolloverEnabled(false);
                } else {
                    botao.setText("");
                    botao.setBackground(Color.WHITE);
                    botao.setForeground(new Color(0, 102, 204));

                    botao.addActionListener(e -> {
                        // Sempre devolve a cor branca à seleção anterior
                        if (botaoSelecionado != null) {
                            botaoSelecionado.setBackground(Color.WHITE);
                        }
                        botaoSelecionado = botao;
                        botaoSelecionado.setBackground(new Color(255, 255, 153));
                    });
                }
                botoes[linha][coluna] = botao;
                painelTabuleiro.add(botao);
            }
        }
        painelJogo.add(painelTabuleiro, BorderLayout.CENTER);

        JPanel painelInferior = new JPanel(new BorderLayout(10, 10));
        painelInferior.setBorder(BorderFactory.createEmptyBorder(0, 25, 20, 25));

        JPanel painelTeclado = new JPanel(new GridLayout(1, 5, 10, 0));
        for (int i = 1; i <= 4; i++) {
            String num = String.valueOf(i);
            JButton btnNum = new JButton(num);
            btnNum.setFont(new Font("Arial", Font.BOLD, 40));
            btnNum.setBackground(new Color(240, 240, 240));
            btnNum.setOpaque(true);
            btnNum.setFocusPainted(false);
            btnNum.addActionListener(e -> {
                if (botaoSelecionado != null) {
                    botaoSelecionado.setText(num);
                    verificarVitoriaSilenciosa();
                } else {
                    JOptionPane.showMessageDialog(this, "Escolha primeiro um quadrado branco lá em cima!", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            });
            painelTeclado.add(btnNum);
        }

        JButton btnApagar = new JButton("X");
        btnApagar.setFont(new Font("Arial", Font.BOLD, 36));
        btnApagar.setBackground(new Color(255, 204, 204));
        btnApagar.setOpaque(true);
        btnApagar.setFocusPainted(false);
        btnApagar.addActionListener(e -> {
            if (botaoSelecionado != null) {
                botaoSelecionado.setText("");
            }
        });
        painelTeclado.add(btnApagar);
        painelInferior.add(painelTeclado, BorderLayout.CENTER);

        JButton btnChecar = new JButton("VERIFICAR SE ESTÁ CERTO");
        btnChecar.setFont(new Font("Arial", Font.BOLD, 18));
        btnChecar.setBackground(new Color(46, 139, 87));
        btnChecar.setForeground(Color.WHITE);
        btnChecar.setOpaque(true);
        btnChecar.setFocusPainted(false);
        btnChecar.setPreferredSize(new Dimension(100, 50));
        btnChecar.addActionListener(e -> executarBotaoChecar());
        painelInferior.add(btnChecar, BorderLayout.SOUTH);

        painelJogo.add(painelInferior, BorderLayout.SOUTH);

        add(painelJogo, "Jogo");
        CardLayout cl = (CardLayout) getContentPane().getLayout();
        cl.show(getContentPane(), "Jogo");

        revalidate();
        repaint();
    }

    // ---------- Lógica de verificação (baseada nas regras do Sudoku) ----------

    private int valorDaCelula(int l, int c) {
        String t = botoes[l][c].getText();
        return t.isEmpty() ? 0 : Integer.parseInt(t);
    }

    /** Retorna true se o número da célula se repete na linha, coluna ou bloco 2x2. */
    private boolean temConflito(int l, int c) {
        int v = valorDaCelula(l, c);
        if (v == 0) return false;

        for (int i = 0; i < 4; i++) {
            if (i != c && valorDaCelula(l, i) == v) return true;
            if (i != l && valorDaCelula(i, c) == v) return true;
        }

        int baseL = (l / 2) * 2;
        int baseC = (c / 2) * 2;
        for (int i = baseL; i < baseL + 2; i++) {
            for (int j = baseC; j < baseC + 2; j++) {
                if ((i != l || j != c) && valorDaCelula(i, j) == v) return true;
            }
        }
        return false;
    }

    private void verificarVitoriaSilenciosa() {
        for (int l = 0; l < 4; l++) {
            for (int c = 0; c < 4; c++) {
                if (valorDaCelula(l, c) == 0 || temConflito(l, c)) {
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(this, "Parabéns! Você resolveu o Sudoku! 🎉", "Vitória!", JOptionPane.INFORMATION_MESSAGE);
    }

    private void executarBotaoChecar() {
        int erros = 0;
        int vazios = 0;

        for (int l = 0; l < 4; l++) {
            for (int c = 0; c < 4; c++) {
                if (valorDaCelula(l, c) == 0) {
                    vazios++;
                } else if (temConflito(l, c)) {
                    erros++;
                }
            }
        }

        if (erros > 0) {
            JOptionPane.showMessageDialog(this,
                    "Ops! Existem números repetidos na mesma linha, coluna ou bloco.\nTente corrigir!",
                    "Quase lá", JOptionPane.WARNING_MESSAGE);
        } else if (vazios > 0) {
            JOptionPane.showMessageDialog(this,
                    "Tudo certo até agora! Ainda faltam " + vazios + " quadrado(s) para preencher.",
                    "Continue!", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Parabéns! Você resolveu o Sudoku! 🎉",
                    "Vitória!", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(JogoSudoku::new);
    }
}
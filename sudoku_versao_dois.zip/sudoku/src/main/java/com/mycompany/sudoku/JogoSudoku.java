package com.mycompany.sudoku;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class JogoSudoku extends JFrame {

    private static final int TAMANHO = 4;
    private final JButton[][] botoes = new JButton[TAMANHO][TAMANHO];
    private final Random random = new Random();

    private int[][] solucao;
    private int[][] inicial;
    private JButton botaoSelecionado;

    private JPanel painelMenu;
    private JPanel painelJogo;
    private JPanel painelRaiz;

    private boolean modoEscuro = false;

    // Cores do tema atualizadas por aplicarTema()
    private Color fundo;
    private Color texto;
    private Color celulaFixa;
    private Color celulaVazia;
    private Color celulaSelecionada;
    private Color textoJogador;
    private Color fundoBotoes;

    public JogoSudoku() {
        setTitle("Sudoku 4x4");
        setSize(520, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        painelRaiz = new JPanel(new CardLayout());
        setContentPane(painelRaiz);

        atualizarCores();
        criarMenuPrincipal();

        setVisible(true);
    }

    private void atualizarCores() {
        if (modoEscuro) {
            fundo = new Color(35, 35, 40);
            texto = new Color(240, 240, 240);
            celulaFixa = new Color(75, 75, 82);
            celulaVazia = new Color(50, 50, 57);
            celulaSelecionada = new Color(105, 90, 45);
            textoJogador = new Color(100, 180, 255);
            fundoBotoes = new Color(65, 65, 72);
        } else {
            fundo = new Color(245, 245, 245);
            texto = new Color(30, 30, 30);
            celulaFixa = new Color(215, 215, 215);
            celulaVazia = Color.WHITE;
            celulaSelecionada = new Color(255, 255, 153);
            textoJogador = new Color(0, 102, 204);
            fundoBotoes = new Color(235, 235, 235);
        }
    }

    private void criarMenuPrincipal() {
        painelMenu = new JPanel(new BorderLayout(20, 20));
        painelMenu.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel titulo = new JLabel("Jogo do Sudoku", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        painelMenu.add(titulo, BorderLayout.NORTH);

        JPanel botoesMenu = new JPanel(new GridLayout(5, 1, 0, 15));
        botoesMenu.setOpaque(false);

        JButton instrucoes = criarBotao("Como Jogar", 20);
        instrucoes.addActionListener(e -> mostrarInstrucoes());

        JButton facil = criarBotao("Jogar - Fácil", 22);
        facil.addActionListener(e -> iniciarJogo(6, "Fácil"));

        JButton medio = criarBotao("Jogar - Médio", 22);
        medio.addActionListener(e -> iniciarJogo(9, "Médio"));

        JButton tema = criarBotao("", 20);
        atualizarTextoTema(tema);
        tema.addActionListener(e -> {
            modoEscuro = !modoEscuro;
            atualizarCores();
            aplicarTema();
            atualizarTextoTema(tema);
        });

        JButton sair = criarBotao("Sair do Jogo", 18);
        sair.addActionListener(e -> System.exit(0));

        botoesMenu.add(instrucoes);
        botoesMenu.add(facil);
        botoesMenu.add(medio);
        botoesMenu.add(tema);
        botoesMenu.add(sair);

        painelMenu.add(botoesMenu, BorderLayout.CENTER);
        painelRaiz.add(painelMenu, "Menu");

        aplicarTema();
    }

    private JButton criarBotao(String textoBotao, int tamanho) {
        JButton botao = new JButton(textoBotao);
        botao.setFont(new Font("Arial", Font.BOLD, tamanho));
        botao.setFocusPainted(false);
        botao.setOpaque(true);
        return botao;
    }

    private void atualizarTextoTema(JButton botao) {
        botao.setText(modoEscuro ? "Modo Claro" : "Modo Escuro");
    }

    private void mostrarInstrucoes() {
        String texto =
                "Como jogar o Sudoku 4x4:\n\n" +
                "1. Escolha um modo para gerar um novo tabuleiro.\n" +
                "2. Os números cinzas são fixos.\n" +
                "3. Clique em um quadrado vazio.\n" +
                "4. Escolha 1, 2, 3 ou 4 no teclado abaixo.\n" +
                "5. Não repita números na mesma linha, coluna ou bloco 2x2.\n" +
                "6. Use VERIFICAR para conferir o progresso.\n\n" +
                "Cada nova partida gera uma solução aleatória.";

        JOptionPane.showMessageDialog(
                this,
                texto,
                "Instruções",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // Gera uma solução completa aleatória usando backtracking.
    private int[][] gerarSolucaoAleatoria() {
        int[][] tabuleiro = new int[TAMANHO][TAMANHO];
        preencherAleatorio(tabuleiro, 0, 0);
        return tabuleiro;
    }

    private boolean preencherAleatorio(int[][] tabuleiro, int linha, int coluna) {
        if (linha == TAMANHO) {
            return true;
        }

        int proximaLinha = coluna == TAMANHO - 1 ? linha + 1 : linha;
        int proximaColuna = coluna == TAMANHO - 1 ? 0 : coluna + 1;

        List<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= TAMANHO; i++) {
            numeros.add(i);
        }
        Collections.shuffle(numeros, random);

        for (int numero : numeros) {
            if (podeColocar(tabuleiro, linha, coluna, numero)) {
                tabuleiro[linha][coluna] = numero;

                if (preencherAleatorio(tabuleiro, proximaLinha, proximaColuna)) {
                    return true;
                }

                tabuleiro[linha][coluna] = 0;
            }
        }

        return false;
    }

    private boolean podeColocar(int[][] tabuleiro, int linha, int coluna, int numero) {
        for (int i = 0; i < TAMANHO; i++) {
            if (tabuleiro[linha][i] == numero || tabuleiro[i][coluna] == numero) {
                return false;
            }
        }

        int baseLinha = (linha / 2) * 2;
        int baseColuna = (coluna / 2) * 2;

        for (int l = baseLinha; l < baseLinha + 2; l++) {
            for (int c = baseColuna; c < baseColuna + 2; c++) {
                if (tabuleiro[l][c] == numero) {
                    return false;
                }
            }
        }

        return true;
    }

    // Remove casas da solução para criar o desafio.
    private int[][] criarTabuleiroInicial(int[][] solucao, int quantidadeDeVazios) {
        int[][] tabuleiro = copiarMatriz(solucao);

        List<Integer> posicoes = new ArrayList<>();
        for (int i = 0; i < TAMANHO * TAMANHO; i++) {
            posicoes.add(i);
        }

        Collections.shuffle(posicoes, random);

        for (int i = 0; i < quantidadeDeVazios; i++) {
            int posicao = posicoes.get(i);
            int linha = posicao / TAMANHO;
            int coluna = posicao % TAMANHO;
            tabuleiro[linha][coluna] = 0;
        }

        return tabuleiro;
    }

    private int[][] copiarMatriz(int[][] original) {
        int[][] copia = new int[TAMANHO][TAMANHO];

        for (int l = 0; l < TAMANHO; l++) {
            System.arraycopy(original[l], 0, copia[l], 0, TAMANHO);
        }

        return copia;
    }

    private void iniciarJogo(int quantidadeDeVazios, String dificuldade) {
        solucao = gerarSolucaoAleatoria();
        inicial = criarTabuleiroInicial(solucao, quantidadeDeVazios);
        botaoSelecionado = null;

        painelJogo = new JPanel(new BorderLayout(15, 15));
        painelJogo.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        JPanel topo = new JPanel(new BorderLayout(10, 10));

        JButton voltar = criarBotao("Voltar", 14);
        voltar.addActionListener(e -> {
            botaoSelecionado = null;
            ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Menu");
            setTitle("Sudoku 4x4");
        });

        JLabel titulo = new JLabel(
                "Sudoku 4x4 - " + dificuldade,
                SwingConstants.CENTER
        );
        titulo.setFont(new Font("Arial", Font.BOLD, 20));

        JButton novo = criarBotao("Novo", 14);
        novo.addActionListener(e -> iniciarJogo(quantidadeDeVazios, dificuldade));

        topo.add(voltar, BorderLayout.WEST);
        topo.add(titulo, BorderLayout.CENTER);
        topo.add(novo, BorderLayout.EAST);

        painelJogo.add(topo, BorderLayout.NORTH);

        JPanel tabuleiro = new JPanel(new GridLayout(4, 4, 6, 6));
        tabuleiro.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        tabuleiro.setOpaque(false);

        for (int linha = 0; linha < TAMANHO; linha++) {
            for (int coluna = 0; coluna < TAMANHO; coluna++) {
                criarCelula(tabuleiro, linha, coluna);
            }
        }

        painelJogo.add(tabuleiro, BorderLayout.CENTER);

        JPanel inferior = new JPanel(new BorderLayout(10, 10));
        inferior.setOpaque(false);
        inferior.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 25));

        JPanel teclado = new JPanel(new GridLayout(1, 5, 8, 0));
        teclado.setOpaque(false);

        for (int numero = 1; numero <= 4; numero++) {
            final String valor = String.valueOf(numero);
            JButton botaoNumero = criarBotao(valor, 30);

            botaoNumero.addActionListener(e -> {
                if (botaoSelecionado == null) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Escolha primeiro um quadrado vazio.",
                            "Aviso",
                            JOptionPane.WARNING_MESSAGE
                    );
                    return;
                }

                botaoSelecionado.setText(valor);
                verificarVitoriaSilenciosa();
            });

            teclado.add(botaoNumero);
        }

        JButton apagar = criarBotao("X", 28);
        apagar.addActionListener(e -> {
            if (botaoSelecionado != null) {
                botaoSelecionado.setText("");
            }
        });
        teclado.add(apagar);

        inferior.add(teclado, BorderLayout.CENTER);

        JButton verificar = criarBotao("VERIFICAR", 18);
        verificar.addActionListener(e -> executarBotaoChecar());

        JPanel painelVerificar = new JPanel();
        painelVerificar.setOpaque(false);
        painelVerificar.add(verificar);

        inferior.add(painelVerificar, BorderLayout.SOUTH);

        painelJogo.add(inferior, BorderLayout.SOUTH);

        painelRaiz.add(painelJogo, "Jogo");
        aplicarTema();

        ((CardLayout) painelRaiz.getLayout()).show(painelRaiz, "Jogo");
        setTitle("Sudoku 4x4 - " + dificuldade);

        revalidate();
        repaint();
    }

    private void criarCelula(JPanel tabuleiro, int linha, int coluna) {
        int numeroInicial = inicial[linha][coluna];

        JButton botao = new JButton();
        botao.setFont(new Font("Arial", Font.BOLD, 36));
        botao.setFocusPainted(false);
        botao.setOpaque(true);

        if (numeroInicial != 0) {
            botao.setText(String.valueOf(numeroInicial));
            botao.setForeground(texto);
            botao.setBackground(celulaFixa);
            botao.setEnabled(false);
        } else {
            botao.setBackground(celulaVazia);
            botao.setForeground(textoJogador);

            botao.addActionListener(e -> {
                if (botaoSelecionado != null) {
                    botaoSelecionado.setBackground(celulaVazia);
                }

                botaoSelecionado = botao;
                botaoSelecionado.setBackground(celulaSelecionada);
            });
        }

        botoes[linha][coluna] = botao;
        tabuleiro.add(botao);
    }

    private int valorDaCelula(int linha, int coluna) {
        String textoBotao = botoes[linha][coluna].getText();

        if (textoBotao.isEmpty()) {
            return 0;
        }

        return Integer.parseInt(textoBotao);
    }

    private boolean temConflito(int linha, int coluna) {
        int valor = valorDaCelula(linha, coluna);

        if (valor == 0) {
            return false;
        }

        for (int i = 0; i < TAMANHO; i++) {
            if (i != coluna && valorDaCelula(linha, i) == valor) {
                return true;
            }

            if (i != linha && valorDaCelula(i, coluna) == valor) {
                return true;
            }
        }

        int baseLinha = (linha / 2) * 2;
        int baseColuna = (coluna / 2) * 2;

        for (int l = baseLinha; l < baseLinha + 2; l++) {
            for (int c = baseColuna; c < baseColuna + 2; c++) {
                if ((l != linha || c != coluna)
                        && valorDaCelula(l, c) == valor) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean tabuleiroCompletoECorreto() {
        for (int l = 0; l < TAMANHO; l++) {
            for (int c = 0; c < TAMANHO; c++) {
                if (valorDaCelula(l, c) == 0 || temConflito(l, c)) {
                    return false;
                }
            }
        }

        return true;
    }

    private void verificarVitoriaSilenciosa() {
        if (tabuleiroCompletoECorreto()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Parabéns! Você resolveu o Sudoku!",
                    "Vitória!",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void executarBotaoChecar() {
        int erros = 0;
        int vazios = 0;

        for (int l = 0; l < TAMANHO; l++) {
            for (int c = 0; c < TAMANHO; c++) {
                if (valorDaCelula(l, c) == 0) {
                    vazios++;
                } else if (temConflito(l, c)) {
                    erros++;
                }
            }
        }

        if (erros > 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Existem números repetidos na mesma linha, coluna ou bloco 2x2.",
                    "Há erros",
                    JOptionPane.WARNING_MESSAGE
            );
        } else if (vazios > 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Até agora está tudo certo! Faltam "
                            + vazios + " espaço(s).",
                    "Continue",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Parabéns! Você resolveu o Sudoku!",
                    "Vitória!",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void aplicarTema() {
        atualizarCores();

        getContentPane().setBackground(fundo);

        if (painelMenu != null) {
            painelMenu.setBackground(fundo);
            atualizarComponentes(painelMenu);
        }

        if (painelJogo != null) {
            painelJogo.setBackground(fundo);
            atualizarComponentes(painelJogo);

            for (int l = 0; l < TAMANHO; l++) {
                for (int c = 0; c < TAMANHO; c++) {
                    JButton botao = botoes[l][c];

                    if (botao == null) {
                        continue;
                    }

                    botao.setForeground(
                            inicial[l][c] != 0 ? texto : textoJogador
                    );

                    if (inicial[l][c] != 0) {
                        botao.setBackground(celulaFixa);
                    } else if (botao == botaoSelecionado) {
                        botao.setBackground(celulaSelecionada);
                    } else {
                        botao.setBackground(celulaVazia);
                    }
                }
            }
        }

        SwingUtilities.updateComponentTreeUI(this);
        repaint();
    }

    private void atualizarComponentes(Container container) {
        for (Component componente : container.getComponents()) {
            if (componente instanceof JLabel) {
                componente.setForeground(texto);
            }

            if (componente instanceof JButton) {
                JButton botao = (JButton) componente;
                botao.setForeground(texto);
                botao.setBackground(fundoBotoes);
            }

            if (componente instanceof JPanel) {
                JPanel painel = (JPanel) componente;
                if (painel.isOpaque()) {
                    painel.setBackground(fundo);
                }
                atualizarComponentes(painel);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(JogoSudoku::new);
    }
}

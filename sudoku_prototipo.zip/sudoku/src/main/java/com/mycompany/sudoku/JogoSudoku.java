package com.mycompany.sudoku;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JogoSudoku extends JFrame {

    private final int[][] SOLUCAO = {
        {1, 2, 3, 4},
        {3, 4, 1, 2},
        {2, 3, 4, 1},
        {4, 1, 2, 3}
    };

    private final int[][] TABULEIRO_INICIAL = {
        {1, 0, 3, 0},
        {0, 4, 0, 2},
        {2, 0, 4, 0},
        {0, 1, 0, 3}
    };

    private JButton[][] botoes = new JButton[4][4];

    public JogoSudoku() {
        setTitle("Meu Primeiro Sudoku 4x4");
        setSize(450, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel lblTitulo = new JLabel("Complete o Sudoku (Números de 1 a 4)", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel painelTabuleiro = new JPanel(new GridLayout(4, 4, 5, 5));
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        for (int linha = 0; linha < 4; linha++) {
            for (int coluna = 0; coluna < 4; coluna++) {
                int numeroInicial = TABULEIRO_INICIAL[linha][coluna];
                
                JButton botao = new JButton();
                botao.setFont(new Font("Arial", Font.BOLD, 28));
                botao.setFocusPainted(false);

                if (numeroInicial != 0) {
                    botao.setText(String.valueOf(numeroInicial));
                    botao.setBackground(new Color(230, 230, 230));
                    botao.setEnabled(false);
                } else {
                    botao.setText("");
                    botao.setBackground(Color.WHITE);
                    botao.setForeground(Color.BLUE);

                    botao.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            String texto = botao.getText();
                            
                            if (texto.equals("")) botao.setText("1");
                            else if (texto.equals("1")) botao.setText("2");
                            else if (texto.equals("2")) botao.setText("3");
                            else if (texto.equals("3")) botao.setText("4");
                            else botao.setText("");

                            verificarVitoriaSilenciosa();
                        }
                    });
                }

                botoes[linha][coluna] = botao;
                painelTabuleiro.add(botao);
            }
        }
        add(painelTabuleiro, BorderLayout.CENTER);

        JButton btnChecar = new JButton("Verificar Meu Progresso");
        btnChecar.setFont(new Font("Arial", Font.BOLD, 18));
        btnChecar.setBackground(new Color(70, 130, 180));
        btnChecar.setForeground(Color.WHITE);
        btnChecar.addActionListener(e -> executarBotaoChecar());
        add(btnChecar, BorderLayout.SOUTH);
    }

    private void verificarVitoriaSilenciosa() {
        for (int l = 0; l < 4; l++) {
            for (int c = 0; c < 4; c++) {
                String textoBotao = botoes[l][c].getText();
                int valorDoBotao = textoBotao.equals("") ? 0 : Integer.parseInt(textoBotao);

                if (valorDoBotao != SOLUCAO[l][c]) {
                    return; 
                }
            }
        }
        JOptionPane.showMessageDialog(this, "Parabéns! Você resolveu o Sudoku! 🧩✨", "Vitória!", JOptionPane.INFORMATION_MESSAGE);
    }

    private void executarBotaoChecar() {
        int erros = 0;
        int vazios = 0;

        for (int l = 0; l < 4; l++) {
            for (int c = 0; c < 4; c++) {
                String textoBotao = botoes[l][c].getText();
                
                if (textoBotao.equals("")) {
                    vazios++;
                } else {
                    int valorDoBotao = Integer.parseInt(textoBotao);
                    if (valorDoBotao != SOLUCAO[l][c]) {
                        erros++;
                    }
                }
            }
        }

        if (vazios == 0 && erros == 0) {
            JOptionPane.showMessageDialog(this, "Tudo perfeito! Você venceu!", "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } else if (erros > 0) {
            JOptionPane.showMessageDialog(this, "Você está quase lá, mas há " + erros + " número(s) incorreto(s). Continue tentando!", "Dica de Progresso", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Até agora todos os números digitados estão certos! Faltam " + vazios + " espaço(s) para preencher.", "Dica de Progresso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JogoSudoku frame = new JogoSudoku();
            frame.setVisible(true);
        });
    }
}
